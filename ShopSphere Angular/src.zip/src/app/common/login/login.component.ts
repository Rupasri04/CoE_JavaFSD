import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';  // ✅ Declare errorMessage

  constructor(private router: Router) {}

  login() {
    if (this.username === 'admin' && this.password === 'admin@123') {
      localStorage.setItem('username', this.username);
      alert('Login Successful');
      this.router.navigate(['/enquiry']); // ✅ Redirect to Enquiry page
      window.location.reload();
    } else {
      this.errorMessage = 'Invalid username or password'; // ✅ Assign error message
    }
  }
}
