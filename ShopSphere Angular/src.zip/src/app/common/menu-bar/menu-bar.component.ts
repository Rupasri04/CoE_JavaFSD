import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.css']
})
export class MenuBarComponent implements OnInit {
  isAuthenticated: boolean = false;
  loginMenu: string = 'Login';

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.checkAuthentication();
  }

  checkAuthentication(): void {
    const username = localStorage.getItem('username');
    if (username) {
      this.isAuthenticated = true;
      this.loginMenu = 'Admin, Logout'; // ✅ Show "Admin, Logout"
    }
  }

  loginHandler(): void {
    if (this.isAuthenticated) {
      // 🔹 Logout
      localStorage.removeItem('username');
      this.isAuthenticated = false;
      this.loginMenu = 'Login';
      this.router.navigate(['/login']); // ✅ Go to Login Page
      window.location.reload(); // ✅ Refresh Page
    } else {
      // 🔹 Go to Login Page
      this.router.navigate(['/login']);
    }
  }
}
