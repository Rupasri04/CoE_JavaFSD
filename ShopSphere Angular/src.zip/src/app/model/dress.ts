export interface Dress {
    id: number;
    title: string;
    description: string;
    price: number;
    image: string;
    quantity?: number;  // To track quantity in the cart
  }
  