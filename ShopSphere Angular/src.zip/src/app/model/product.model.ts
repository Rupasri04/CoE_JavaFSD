// src/app/models/product.model.ts

export class Product {
    constructor(
      public id: number,
      public name: string,
      public description: string,
      public price: number,
      public imageUrl: string,
      public quantity: number = 1  // Initialize quantity to 1
    ) {}
  }
  