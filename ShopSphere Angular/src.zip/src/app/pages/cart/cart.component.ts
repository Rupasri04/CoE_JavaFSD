import { Component, OnInit } from '@angular/core';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems: any[] = [];
  totalAmount: number = 0;
  gst: number = 0.04;  // 4% GST
  deliveryCharge: number = 40;  // Delivery charge
  gstAmount: number = 0;  // GST amount
  
  constructor(private cartService: CartService) {}

  ngOnInit(): void {
    this.cartItems = this.cartService.getCartItems(); // Fetch cart items from CartService
    this.calculateTotal();
  }

  
  calculateTotal(): void {
    let subtotal = 0;

    this.cartItems.forEach(item => {
      subtotal += item.price * item.quantity; // Adding price of all items
    });

    this.gstAmount = subtotal * this.gst;  // 4% GST amount
    this.totalAmount = subtotal + this.gstAmount + this.deliveryCharge; // Adding GST and Delivery charge
  }
}
