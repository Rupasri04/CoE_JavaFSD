import { Component } from '@angular/core';

@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.css']
})
export class EnquiryComponent {
  enquiries = [
    { name: 'Alice Johnson', email: 'alice@example.com', message: 'How can I track my order?' },
    { name: 'Bob Smith', email: 'bob@example.com', message: 'Do you offer international shipping?' },
    { name: 'Charlie Brown', email: 'charlie@example.com', message: 'What payment methods do you accept?' }
  ];

  newEnquiry = { name: '', email: '', message: '' };

  submitEnquiry() {
    if (this.newEnquiry.name && this.newEnquiry.email && this.newEnquiry.message) {
      this.enquiries.push({ ...this.newEnquiry });
      this.newEnquiry = { name: '', email: '', message: '' }; // Reset form after submission
    }
  }
}
