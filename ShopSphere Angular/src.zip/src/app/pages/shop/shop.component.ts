import { Component, OnInit } from '@angular/core';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {
  dresses = [
    { id: 1, name: 'Red Dress', image: 'assets/red-dress.jpg', description: 'A beautiful red dress', price: 849.99, quantity: 0, color: 'red' },
    { id: 2, name: 'Blue Dress', image: 'assets/blue-dress.jpg', description: 'A stylish blue dress', price: 219.99, quantity: 0, color: 'blue' },
    { id: 3, name: 'Black Dress', image: 'assets/black-dress.jpg', description: 'A chic black dress', price: 499.99, quantity: 0, color: 'black' },
    { id: 4, name: 'Green Dress', image: 'assets/green-dress.jpg', description: 'A stunning green dress', price: 769.99, quantity: 0, color: 'green' },
    { id: 5, name: 'Yellow Dress', image: 'assets/yellow-dress.jpg', description: 'A vibrant yellow dress', price: 619.99, quantity: 0, color: 'yellow' },
    { id: 6, name: 'Pink Dress', image: 'assets/pink-dress.jpg', description: 'A cute pink dress', price: 309.99, quantity: 0, color: 'pink' },
    { id: 7, name: 'White Dress', image: 'assets/white-dress.jpg', description: 'A clean, elegant white dress', price: 259.99, quantity: 0, color: 'white' },
    { id: 8, name: 'Purple Dress', image: 'assets/purple-dress.jpg', description: 'A bold purple dress', price: 649.99, quantity: 0, color: 'purple' },
    { id: 9, name: 'Orange Dress', image: 'assets/orange-dress.jpg', description: 'A bright orange dress', price: 919.99, quantity: 0, color: 'orange' },
    { id: 10, name: 'Grey Dress', image: 'assets/grey-dress.jpg', description: 'A sophisticated grey dress', price: 259.99, quantity: 0, color: 'grey' }
  ];

  selectedFilter: string = 'price'; // Default to price filter
  selectedPrice = { min: false, max: false };
  selectedColors: { [key: string]: boolean } = { red: false, blue: false, green: false, black: false, yellow: false, pink: false };

  constructor(private cartService: CartService) {}

  ngOnInit(): void {}

  addToCart(dress: any): void {
    this.cartService.addToCart(dress);
    alert(`${dress.name} added to cart with quantity: ${dress.quantity}`);
  }

  increaseQuantity(dress: any): void {
    dress.quantity++;
  }

  decreaseQuantity(dress: any): void {
    if (dress.quantity > 1) {
      dress.quantity--;
    }
  }

  // Handle the change in filter type selection (Price or Color)
  onFilterChange() {
    // Reset selection when switching filters
    if (this.selectedFilter === 'price') {
      this.selectedColors = { red: false, blue: false, green: false, black: false, yellow: false, pink: false };
    } else if (this.selectedFilter === 'color') {
      this.selectedPrice = { min: false, max: false };
    }
  }

  // Filter function for price
  filterByPrice() {
    if (this.selectedPrice.min || this.selectedPrice.max) {
      return this.dresses.filter(dress => {
        if (this.selectedPrice.min && dress.price < 500) {
          return true;
        } else if (this.selectedPrice.max && dress.price >= 500) {
          return true;
        }
        return false;
      });
    }
    return this.dresses;
  }

  // Filter function for color
  filterByColor() {
    let selectedColors = Object.keys(this.selectedColors).filter(key => this.selectedColors[key]);
    if (selectedColors.length > 0) {
      return this.dresses.filter(dress => selectedColors.includes(dress.color));
    }
    return this.dresses;
  }

  // Combined filter function
  getFilteredDresses() {
    let filteredByPrice = this.filterByPrice();
    return this.filterByColor().filter(dress => filteredByPrice.includes(dress));
  }

  // Reload the page after filtering
  onGoClick(): void {
    window.location.reload();
  }
}
