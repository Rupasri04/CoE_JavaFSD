import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private router: Router) {}

  // Check if the user is logged in
  isLoggedIn(): boolean {
    return sessionStorage.getItem('userHasAccessToEnquiry') === 'true';
  }

  // Log the user in by setting access status
  login(): void {
    sessionStorage.setItem('userHasAccessToEnquiry', 'true');
  }

  // Log the user out by removing access status
  logout(): void {
    sessionStorage.removeItem('userHasAccessToEnquiry');
    this.router.navigate(['/login']);  // Redirect to login page after logout
  }
}
