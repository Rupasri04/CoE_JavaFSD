import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartItems: any[] = [];

  constructor() { }

  // Add item to cart
  addToCart(item: any): void {
    const existingItem = this.cartItems.find(cartItem => cartItem.id === item.id);
    if (existingItem) {
      existingItem.quantity += item.quantity; 
    } else {
      this.cartItems.push(item); 
    }
  }

  // Get all items in the cart
  getCartItems(): any[] {
    return this.cartItems;
  }

  // Clear the cart (optional)
  clearCart(): void {
    this.cartItems = [];
  }
}
